-- Car Rental Management System
-- Based on the Open Ended Lab Report

CREATE DATABASE IF NOT EXISTS CarGoRentals;
USE CarGoRentals;

-- =========================
-- 1. CUSTOMER TABLE
-- =========================
CREATE TABLE Customer (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Phone VARCHAR(20) NOT NULL UNIQUE
);

-- =========================
-- 2. VEHICLE TABLE
-- =========================
CREATE TABLE Vehicle (
    VehicleID INT AUTO_INCREMENT PRIMARY KEY,
    VehicleNumber VARCHAR(30) NOT NULL UNIQUE,
    Model VARCHAR(100) NOT NULL,
    DailyRate DECIMAL(10,2) NOT NULL CHECK (DailyRate > 0),
    AvailabilityStatus VARCHAR(20) NOT NULL DEFAULT 'Available',
    CHECK (AvailabilityStatus IN ('Available', 'Rented'))
);

-- =========================
-- 3. RENTAL TABLE
-- =========================
CREATE TABLE Rental (
    RentalID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT NOT NULL,
    VehicleID INT NOT NULL,
    RentalDate DATE NOT NULL,
    ReturnDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    FOREIGN KEY (VehicleID) REFERENCES Vehicle(VehicleID),
    CHECK (ReturnDate IS NULL OR ReturnDate >= RentalDate)
);

-- =========================
-- 4. PAYMENT TABLE
-- =========================
CREATE TABLE Payment (
    PaymentID INT AUTO_INCREMENT PRIMARY KEY,
    RentalID INT NOT NULL,
    Amount DECIMAL(10,2) NOT NULL CHECK (Amount > 0),
    PaymentDate DATE NOT NULL DEFAULT (CURRENT_DATE),
    FOREIGN KEY (RentalID) REFERENCES Rental(RentalID)
);

-- =========================
-- SAMPLE DATA
-- =========================
INSERT INTO Customer (Name, Phone) VALUES
('Ali Khan', '03001234567'),
('Sara Ahmed', '03111234567'),
('Hamza Malik', '03221234567'),
('Ayesha Noor', '03331234567'),
('Usman Raza', '03441234567');

INSERT INTO Vehicle (VehicleNumber, Model, DailyRate, AvailabilityStatus) VALUES
('LEA-1234', 'Toyota Corolla', 5000.00, 'Available'),
('LEB-5678', 'Honda Civic', 7000.00, 'Rented'),
('LEC-9012', 'Suzuki Swift', 4000.00, 'Available'),
('LED-3456', 'Toyota Yaris', 5500.00, 'Rented'),
('LEE-7890', 'Honda City', 6000.00, 'Available');

INSERT INTO Rental (CustomerID, VehicleID, RentalDate, ReturnDate) VALUES
(1, 2, '2026-09-10', '2026-09-12'),
(2, 4, '2026-09-15', NULL),
(3, 1, '2026-09-05', '2026-09-06');

INSERT INTO Payment (RentalID, Amount, PaymentDate) VALUES
(1, 14000.00, '2026-09-12'),
(2, 7000.00, '2026-09-15'),
(3, 5000.00, '2026-09-06');

-- =========================
-- 5. SQL JOIN QUERIES
-- =========================

-- 5.1 Rental Details - INNER JOIN
SELECT
    c.Name AS CustomerName,
    v.VehicleNumber,
    r.RentalDate,
    r.ReturnDate
FROM Rental r
INNER JOIN Customer c ON r.CustomerID = c.CustomerID
INNER JOIN Vehicle v ON r.VehicleID = v.VehicleID;

-- 5.2 Customers with Rentals, including customers with no rentals - LEFT JOIN
SELECT
    c.CustomerID,
    c.Name AS CustomerName,
    r.RentalID,
    r.RentalDate,
    r.ReturnDate
FROM Customer c
LEFT JOIN Rental r ON c.CustomerID = r.CustomerID;

-- 5.3 Vehicles with Current Rentals - LEFT JOIN
SELECT
    v.VehicleID,
    v.VehicleNumber,
    v.Model,
    r.RentalID,
    r.RentalDate,
    r.ReturnDate
FROM Vehicle v
LEFT JOIN Rental r
    ON v.VehicleID = r.VehicleID
    AND r.ReturnDate IS NULL;

-- 5.4 Total Rentals per Customer - GROUP BY + COUNT
SELECT
    c.CustomerID,
    c.Name AS CustomerName,
    COUNT(r.RentalID) AS TotalRentals
FROM Customer c
LEFT JOIN Rental r ON c.CustomerID = r.CustomerID
GROUP BY c.CustomerID, c.Name;

-- =========================
-- 6. VIEW
-- =========================
CREATE OR REPLACE VIEW RentalPaymentView AS
SELECT
    r.RentalID,
    c.CustomerID,
    c.Name AS CustomerName,
    c.Phone,
    v.VehicleID,
    v.VehicleNumber,
    v.Model,
    v.DailyRate,
    r.RentalDate,
    r.ReturnDate,
    p.PaymentID,
    p.Amount AS PaymentAmount,
    p.PaymentDate
FROM Rental r
INNER JOIN Customer c ON r.CustomerID = c.CustomerID
INNER JOIN Vehicle v ON r.VehicleID = v.VehicleID
LEFT JOIN Payment p ON r.RentalID = p.RentalID;

-- Test the view
SELECT * FROM RentalPaymentView;

-- =========================
-- 7. STORED PROCEDURE
-- Registers a new rental and calculates total rent
-- =========================
DELIMITER //

CREATE PROCEDURE RegisterRental (
    IN p_CustomerID INT,
    IN p_VehicleID INT,
    IN p_RentalDate DATE,
    IN p_ReturnDate DATE
)
BEGIN
    DECLARE v_DailyRate DECIMAL(10,2);
    DECLARE v_TotalDays INT;
    DECLARE v_TotalRent DECIMAL(10,2);
    DECLARE v_Status VARCHAR(20);

    SELECT DailyRate, AvailabilityStatus
    INTO v_DailyRate, v_Status
    FROM Vehicle
    WHERE VehicleID = p_VehicleID;

    IF v_DailyRate IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Vehicle does not exist';
    END IF;

    IF v_Status = 'Rented' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Vehicle is already rented';
    END IF;

    IF p_ReturnDate IS NULL THEN
        SET v_TotalDays = 1;
    ELSE
        SET v_TotalDays = DATEDIFF(p_ReturnDate, p_RentalDate);

        IF v_TotalDays <= 0 THEN
            SET v_TotalDays = 1;
        END IF;
    END IF;

    SET v_TotalRent = v_DailyRate * v_TotalDays;

    INSERT INTO Rental (CustomerID, VehicleID, RentalDate, ReturnDate)
    VALUES (p_CustomerID, p_VehicleID, p_RentalDate, p_ReturnDate);

    UPDATE Vehicle
    SET AvailabilityStatus = 'Rented'
    WHERE VehicleID = p_VehicleID;

    SELECT
        LAST_INSERT_ID() AS RentalID,
        v_TotalDays AS TotalDays,
        v_TotalRent AS TotalRentalCost;
END //

DELIMITER ;

-- Example procedure call:
-- CALL RegisterRental(4, 3, '2026-09-20', '2026-09-22');

-- =========================
-- 8. INDEXES FOR OPTIMIZATION
-- =========================
CREATE INDEX idx_rental_customer ON Rental(CustomerID);
CREATE INDEX idx_rental_vehicle ON Rental(VehicleID);

-- Check indexes
SHOW INDEX FROM Rental;
